<?php
class main_model extends CI_Model
{
     public function getapcians()
        {
         $query= $this->db->get("apcians");
           return $query;   
	}
}

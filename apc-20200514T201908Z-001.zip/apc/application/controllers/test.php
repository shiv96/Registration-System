<?php
	class test extends CI_Controller
	{
		public function index()
		{
			echo "Hello World!";
		}
	
	}
?>	
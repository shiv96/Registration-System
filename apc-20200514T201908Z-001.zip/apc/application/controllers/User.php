<?php
class User extends CI_Controller 
{
	public function __construct()
	{
	parent::__construct();
	$this->load->database();
	$this->load->helper('url');
        $this->load->library('form_validation');
        $this->load->library('email');
        $this->load->library('session');
	}
 
	public function index()
	{
		
		if($this->input->post('register'))
		{
		$n=$this->input->post('name');
		$e=$this->input->post('email');
		$m=$this->input->post('mobile');
                $a=$this->input->post('apcians_id');
		$c=$this->input->post('branch');
                $y=$this->input->post('year');
                $u=$this->input->post('ID_UNIQUE');
                //$rd=$this->input->post->date('Y-m-d');
                $date = date('Y-m-d H:i:s');
                $ip=$this->input->post('ip');
                
                
                $que=$this->db->query("select * from apcians where apcians_id='".$a."'");
		$row = $que->num_rows();
		if($row)
		{
                $que1=$this->db->query("insert into student values('','$n','$e','$m','$c','$y','$u','$a','$date','$ip')");
		$que2=$this->db->query("insert into apcians values('','$a','','$n','$c','$y','$e','$u','$date')");
		$data['error']="<h3 style='color:blue'>You have registered successfully</h3>";
		}
                else
                {
                   $data['error']="<h3 style='color:red'>WRONG APCIAN ID</h3>"; 
                }
                
                
                
                }
	$this->load->view('student_registration');	
    }
    
    
    public function apcians()
    {
       
                $query=$this->db->get("apcians");
                $data["fetch_data"] = $query;
               
        
               if($this->input->post('login'))
		{
                    $n=$this->input->post('uname');
                    $p=$this->input->post('psw');
                    
                    
                $que=$this->db->query("select * from apcians where apcians_id='".$n."' AND password='".$p."'");
		$row = $que->num_rows();
		if($row)
		{
                redirect(base_url().'user/valid/'.$n);
		}
                else
                { 
                   redirect(base_url().'user/invalid');
                }
                 
                    
        
                }
                       
            $this->load->view('apcians',$data);            
            
    }
        
    public function valid($n)
    {
               // $this->db->where('apcians_id', $id);
               // echo $n;
                $this->db->select('*');
                $this->db->from('apcians');
                $this->db->where('apcians_id', $n );
                $query = $this->db->get();
                $data["fetch_data"] = $query;
                
        
                
                $this->load->view('valid',$data);
        
    }
    
    public function send_email($apcian_id,$reg_name,$email_id,$branch,$year,$qr_code)
    {
                        
        echo $email_id;
        echo $qr_code;
        
        
               
        
                
        
        
        
                        $data['img_url']="";
		
		
			$this->load->library('ciqrcode');
			$qr_image=$qr_code.'.png';
			$params['data'] = $qr_code;
			$params['level'] = 'H';
			$params['size'] = 8;
			$params['savename'] =FCPATH."assets/image/".$qr_image;
			if($this->ciqrcode->generate($params))
			{
				$data['img_url']=$qr_image;	
			}
		
		
            
                $config = array(
                    'protocol' => 'smtp',
                    'smtp_host' => 'smtp.gmail.com',
                    'smtp_port' => 465,
                    'smtp_user' => 'shivhansoti18@gmail.com',
                    'smtp_pass' => '9998975419',
                    'mailtype' => 'html',
                    'charset' => 'utf-8'
                );
                $this->email->initialize($config);
                $this->email->set_mailtype("html");
                $this->email->set_newline("\r\n");


                $from_email = "shivhansoti18@gmail.com";
                $to_email = $email_id;


               
                $this->load->library('email', $config);
                  
                $this->email->from($from_email, 'APC');
                $this->email->to($to_email);
                $this->email->cc('shivhansotica@gmail.com');
                $this->email->subject('Email Test');
                // $this->email->message('<p style="color:red;">Testing the email class.</p>'); 
               
               // $message =" Your name is " .$name;
                //$message .=" Your ID is : ".$student_id;
              // $this->email->message("Your " . '<h1 style="color:blue;">'. " EMAIL ID  :- " . '<font color="red">' . $email_id . '</font>' . '</h1>');
                $this->email->message("Your " . '<h1 style="color:blue;">'. " EMAIL ID  :- " . '<font color="red">' . $email_id . '</font>' . '</h1>'  . "\n". '<h1 style="color:blue;">'. "Name :-  " . $reg_name . '</h1>' . "\n". '<h1 style="color:blue;">'. "Branch :-  " . $branch . '</h1>'."\n". '<h1 style="color:blue;">'. "Year :-  " . $year . '</h1>');
               // $cid = $this->email->attachment_cid($filename);
              
                $this->email->attach('assets/image/'.$qr_image);
                
                //$this->email->message("Your " . '<h1 style="color:black;">'. "ID :- " . '</h1>' .'<h1 style="color:blue;">'. $student_id .'</h1>'  . "\n". '<h1 style="color:blue;">'. "Name" . '</h1>'.'<h1 style="color:green;">'. $name . '</h1>');
                
                
                
               
                //Send mail 
                if ($this->email->send())
                    {
                    $this->session->set_flashdata("email_sent", "Email is sent to your email address successfully.");
                    redirect('User/valid/'.$apcian_id);
                } 
                else
                    {
                    $this->session->set_flashdata("email_sent", "Error in sending Email.");
                }
                
                
            
         
                
    }
    
    
     public function invalid()
    {
                 
        
    }
     
        
        
        
        
}
?>
 <!DOCTYPE html>
<html lang="en">
<title>STUDY CIRCLE</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {font-family: "Lato", sans-serif}
.mySlides {display: none}
</style>
<body>
    
    <?php echo @$error; echo $this->session->flashdata('email_sent'); ?>

<!-- Navbar -->
<div class="w3-top">
  <div class="w3-bar w3-black w3-card">
    <a class="w3-bar-item w3-button w3-padding-large w3-hide-medium w3-hide-large w3-right" href="javascript:void(0)" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
    <a href="#" class="w3-bar-item w3-button w3-padding-large">HOME</a>
    <a href="#band" class="w3-bar-item w3-button w3-padding-large w3-hide-small">EVENT</a>
    <a href="#tour" class="w3-bar-item w3-button w3-padding-large w3-hide-small">REGISTER</a>
    <a href="#contact" class="w3-bar-item w3-button w3-padding-large w3-hide-small">CONTACT</a>

  </div>
</div>

<!-- Navbar on small screens (remove the onclick attribute if you want the navbar to always show on top of the content when clicking on the links) -->
<div id="navDemo" class="w3-bar-block w3-black w3-hide w3-hide-large w3-hide-medium w3-top" style="margin-top:46px">
  <a href="#band" class="w3-bar-item w3-button w3-padding-large" onclick="myFunction()">BAND</a>
  <a href="#tour" class="w3-bar-item w3-button w3-padding-large" onclick="myFunction()">TOUR</a>
  <a href="#contact" class="w3-bar-item w3-button w3-padding-large" onclick="myFunction()">CONTACT</a>
  <a href="#" class="w3-bar-item w3-button w3-padding-large" onclick="myFunction()">MERCH</a>
</div>

<!-- Page content -->
<div class="w3-content" style="max-width:2000px;margin-top:46px">

  <!-- Automatic Slideshow Images -->
  <div class="mySlides w3-display-container w3-center">
      <img src="<?php echo base_url()?>assets/image/bg1.jpg" style="width:100%;height:700px">
    <div class="w3-display-bottommiddle w3-container w3-text-white w3-padding-32 w3-hide-small">
      <h1>STUDY CIRCLE 2019</h1>
      <p><b>We heartily welcome you!</b></p>   
    </div>
  </div>
  <div class="mySlides w3-display-container w3-center">
    <img src="<?php echo base_url()?>assets/image/bg4.jpg" style="width:100%;height:700px">
    <div class="w3-display-bottommiddle w3-container w3-text-white w3-padding-32 w3-hide-small">
       <h1>STUDY CIRCLE 2019</h1>
      <p><b>We heartily welcome you!</b></p>    
    </div>
  </div>
  <div class="mySlides w3-display-container w3-center">
    <img src="<?php echo base_url()?>assets/image/bg3.jpg" style="width:100%">
    <div class="w3-display-bottommiddle w3-container w3-text-white w3-padding-32 w3-hide-small">
        <h1>STUDY CIRCLE 2019</h1>
      <p><b>We heartily welcome you!</b></p>
    </div>
  </div>

  <!-- The Band Section -->
  <div class="w3-container w3-content w3-center w3-padding-64" style="max-width:800px" id="band">
    <h2 class="w3-wide">WHAT IS IT?</h2>
    <p class="w3-opacity"><i>EDUCATIONAL TALK</i></p>
    <p class="w3-justify"> Study Circle is an yearly event Organised by Akashar Purusottam Chattralaya in which talk about "educational" with an essence of "Spirituality"
        is delivered by well known bodies.
        <p class="w3-justify">
        This year Pu.Gyanvatsal swami who is well-knows among the youth is going to deliver a speech. 
        </p>
        </p>
    <div class="w3-row w3-padding-32">
      <div class="w3-third">
        <p>Pu. Gyanvatsal Swami speech on creativity</p>
       <a href="https://www.youtube.com/watch?v=8I8sml5IA2s">
           <img src="<?php echo base_url()?>assets/image/gv1.jpg" class="w3-round w3-margin-bottom" alt="Random Name" style="width:60%;height:100px">
           </a>
      </div>
      <div class="w3-third">
          <p>Pu. Gyanvatsal Swami Tedx speech MS. University Baroda  &nbsp;</p>
         <a href="https://www.youtube.com/watch?v=MmlEQwdqlfo">
        <img src="<?php echo base_url()?>assets/image/gv4.png" class="w3-round w3-margin-bottom" alt="Random Name" style="width:60%;height:100px">
        </a>
      </div>
      <div class="w3-third">
        <p> &nbsp;Pu. Gyanvatsal Swami speech on public image </p>
         <a href="https://www.youtube.com/watch?v=LNdwzOdkynI">
        <img src="<?php echo base_url()?>assets/image/gv3.jpg" class="w3-round" alt="Random Name" style="width:60%;height:100px">
        </a>
      </div>
    </div>
  </div>

  <!-- The Tour Section -->
  <div class="w3-black" id="tour">
    <div class="w3-container w3-content w3-padding-64" style="max-width:800px">
      <h2 class="w3-wide w3-center">EVENT DATE: 22-FEB-2019</h2>
      <p class="w3-opacity w3-center"><i>Specify below details to Register!</i></p><br>

      <ul class="w3-ul w3-border w3-white w3-text-grey">
          
          
          
          
          <form method="post" action="<?php echo base_url('User/index') ?>">
		<table width="600" align="center" border="1" cellspacing="5" cellpadding="5">
	<tr>
		<td colspan="2"><?php echo @$error; echo $this->session->flashdata('email_sent'); ?> </td>
                
	</tr>	
        
        
        
        <tr>
            
        </tr>
        
  <tr>
    <td width="230">Enter Your Name </td>
    <td width="329"><input type="text" name="name"/></td>
  </tr>
  
  <tr>
    <td>Enter Your Email </td>
    <td><input type="text" name="email"/></td>
  </tr>
  
  

  <tr>
    <td>Enter Your Mobile </td>
    <td><input type="text" name="mobile"/></td>
  </tr>
  
  
  <tr>
    <td>Enter Refrence name </td>
    <td><input type="text" name="apcians_id"/></td>
  </tr>
  
  <tr>
    <td>Select Your Branch </td>
    <td>
	<select name="branch">
		<option value="">Select Branch</option>
		<option>CE</option>
		<option>IT</option>
		<option>CH</option>
                <option>MH</option>
                <option>EC</option>
                <option>CL</option>
                <option>BCA</option>
                <option>MCA</option>
                <option>Other</option>
                <option>Other</option>
                <option>Other</option>
                
	</select>
	</td>
  </tr>
  
  
  <tr>
    <td>Select Your Year </td>
    <td>
	<select name="year">
		<option value="">Select Year</option>
                <option>10th std</option>
                <option>11th std</option>
                <option>12th std</option>
                
		<option>1</option>
		<option>2</option>
		<option>3</option>
                <option>4</option>
                <option>5</option>
                
                <option>Other</option>
                <option>Other</option>
                <option>Other</option>
                
                
	</select>
	</td>
  </tr>
  
  
   <input type="hidden" id="ip" value="" name="ip">
  
  <tr>
    <td colspan="2" align="center">
	<input type="submit" name="register" value="Register Me"/></td>
  </tr>  
  
  <input type="hidden" id="ip" value="" name="ip">
  
</table>
        
        
        
        <input type="hidden" name="ID_UNIQUE" id="ID_UNIQUE" />
   <script>
      var now = new Date();
      var randomNum = '';
      randomNum += Math.round(Math.random()*9);
      randomNum += Math.round(Math.random()*9);
      randomNum += now.getTime();
      var elem = document.getElementById("ID_UNIQUE").value = randomNum;
 

function getUserIP(onNewIP) { //  onNewIp - your listener function for new IPs
    //compatibility for firefox and chrome
    var myPeerConnection = window.RTCPeerConnection || window.mozRTCPeerConnection || window.webkitRTCPeerConnection;
    var pc = new myPeerConnection({
        iceServers: []
    }),
    noop = function() {},
    localIPs = {},
    ipRegex = /([0-9]{1,3}(\.[0-9]{1,3}){3}|[a-f0-9]{1,4}(:[a-f0-9]{1,4}){7})/g,
    key;

    function iterateIP(ip) {
        if (!localIPs[ip]) onNewIP(ip);
        localIPs[ip] = true;
    }

     //create a bogus data channel
    pc.createDataChannel("");

    // create offer and set local description
    pc.createOffer(function(sdp) {
        sdp.sdp.split('\n').forEach(function(line) {
            if (line.indexOf('candidate') < 0) return;
            line.match(ipRegex).forEach(iterateIP);
        });
        
        pc.setLocalDescription(sdp, noop, noop);
    }, noop); 

    //listen for candidate events
    pc.onicecandidate = function(ice) {
        if (!ice || !ice.candidate || !ice.candidate.candidate || !ice.candidate.candidate.match(ipRegex)) return;
        ice.candidate.candidate.match(ipRegex).forEach(iterateIP);
    };
}

// Usage

getUserIP(function(ip){
		document.getElementById("ip").value =ip;
});

</script>
}
        
       
	</form>

          
          
          
          
        
      </ul>
      <br>
      <br>
      <h2 class="w3-wide w3-center"></h2>
      <p class="w3-opacity w3-center"><i>SOME GLYMPES AT PREVIOUS YEAR'S SPEAKER!</i></p><br>

      <div class="w3-row-padding w3-padding-32" style="margin:0 -16px">
        <div class="w3-third w3-margin-bottom">
            <img src="<?php echo base_url()?>assets/image/am1.jpg" alt="New York" style="width:100%" class="w3-hover-opacity">
          <div class="w3-container w3-white">
            <p><b>STUDY CIRCLE 2016</b></p>
            <p class="w3-opacity">Feb 8 2016</p>
            <p>Pu.Apurvamuni Swami.</p>
           </div>
        </div>
        <div class="w3-third w3-margin-bottom">
          <img src="<?php echo base_url()?>assets/image/aj1.jpg" alt="Paris" style="width:100%" class="w3-hover-opacity">
          <div class="w3-container w3-white">
            <p><b>STUDY CIRCLE 2017</b></p>
            <p class="w3-opacity">Feb 8 Nov 2017</p>
            <p>Pu.AdarshJivan Swami.</p>
         </div>
        </div>
        <div class="w3-third w3-margin-bottom">
          <img src="<?php echo base_url()?>assets/image/ss1.jpg" alt="San Francisco" style="width:100%" class="w3-hover-opacity">
          <div class="w3-container w3-white">
            <p><b>STUDY CIRCLE 2018</b></p>
            <p class="w3-opacity">Feb 4 2018</p>
            <p>Sailesh Sagparya.</p>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Ticket Modal -->
 
  <!-- The Contact Section -->
  <div class="w3-container w3-content w3-padding-64" style="max-width:800px" id="contact">
    <h2 class="w3-wide w3-center">CONTACT</h2>
    <p class="w3-opacity w3-center"><i>Queries? Drop a note!</i></p>
    <div class="w3-row w3-padding-32">
      <div class="w3-col m6 w3-large w3-margin-bottom">
        <i class="fa fa-map-marker" style="width:30px"></i> Nadiad, Gujarat<br>
        <i class="fa fa-phone" style="width:30px"></i> Phone: +91 9998990445<br>
        <i class="fa fa-envelope" style="width:30px"> </i> Email: apcekghar@mail.com<br>
      </div>
      <div class="w3-col m6">
        <form action="/action_page.php" target="_blank">
          <div class="w3-row-padding" style="margin:0 -16px 8px -16px">
            <div class="w3-half">
              <input class="w3-input w3-border" type="text" placeholder="Name" required name="Name">
            </div>
            <div class="w3-half">
              <input class="w3-input w3-border" type="text" placeholder="Email" required name="Email">
            </div>
          </div>
          <input class="w3-input w3-border" type="text" placeholder="Message" required name="Message">
          <button class="w3-button w3-black w3-section w3-right" type="submit">SEND</button>
        </form>
      </div>
    </div>
  </div>
  
<!-- End Page Content -->
</div>

<!-- Image of location/map -->
<img src="/w3images/map.jpg" class="w3-image w3-greyscale-min" style="width:100%">

<!-- Footer -->
<footer class="w3-container w3-padding-64 w3-center w3-opacity w3-light-grey w3-xlarge">
  <i class="fa fa-facebook-official w3-hover-opacity"></i>
  <i class="fa fa-instagram w3-hover-opacity"></i>
  <i class="fa fa-snapchat w3-hover-opacity"></i>
  <i class="fa fa-pinterest-p w3-hover-opacity"></i>
  <i class="fa fa-twitter w3-hover-opacity"></i>
  <i class="fa fa-linkedin w3-hover-opacity"></i>
  
</footer>

<script>
// Automatic Slideshow - change image every 4 seconds
var myIndex = 0;
carousel();

function carousel() {
  var i;
  var x = document.getElementsByClassName("mySlides");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";  
  }
  myIndex++;
  if (myIndex > x.length) {myIndex = 1}    
  x[myIndex-1].style.display = "block";  
  setTimeout(carousel, 4000);    
}

// Used to toggle the menu on small screens when clicking on the menu button
function myFunction() {
  var x = document.getElementById("navDemo");
  if (x.className.indexOf("w3-show") == -1) {
    x.className += " w3-show";
  } else { 
    x.className = x.className.replace(" w3-show", "");
  }
}

// When the user clicks anywhere outside of the modal, close it
var modal = document.getElementById('ticketModal');
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
</script>

</body>
</html>







    
    
    
    
</html>
<hmtl>
    <head>
        <title>STUDENT DETAILS</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
         <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    </head>

    <body>
        
        
        

        
            
        
        
        <?php
		if($this->session->flashdata('success_msg')){
	?>
		<div class="alert alert-success">
			<?php echo $this->session->flashdata('success_msg'); ?>
		</div>
	<?php		
		}
	?>


	<?php
		if($this->session->flashdata('error_msg')){
	?>
		<div class="alert alert-success">
			<?php echo $this->session->flashdata('error_msg'); ?>
		</div>
	<?php		
		}
	?>
        
        
    
   <h3>CRUD Operation using Codeigniter</h3><br />  
   
       
        
        
    <form  action="<?php echo base_url('user/valid') ?>" method="POST" ">
      <div class="table-responsive">  
           <table class="table table-bordered">  
                <tr>
                     
                     <th>SR_NO</th>  
                     <th>APCIAN_ID</th> 
                     <th>QR_CODE</th>
                     <th>QR_CODE_image</th>
                     <th>REGISTER NAME</th>
                     <th>REGISTER EMAIL-ID</th>
                     <th>REGISTER BRANCH</th>
                     <th>REGISTER YEAR</th>
                     <td>SEND EMAIL</td>
                     
                     
                       
                </tr>  
           <?php  
           if($fetch_data->num_rows() > 0)  
           {  
                foreach($fetch_data->result() as $row)  
                {  
           ?>  
                <tr>  
                     
                     <td><?php echo $row->id ?></td>  
                     <td><?php echo $row->apcians_id; ?></td>
                     <td><?php echo $row->qr_code;?></td>
                     <td><image src="<?php echo base_url();?>/assets/image/<?php echo $row->qr_code; ?>.png"</td>
                     <td><?php echo $row->reg_name; ?></td> 
                     <td><?php echo $row->email_id; ?></td>
                     <td><?php echo $row->branch; ?></td> 
                     <td><?php echo $row->year; ?></td> 
                   
                     
                     <?php 
                     $btnid= $row->apcians_id;
                     ?>
                     <td>
                         <a href="<?php echo base_url('user/send_email/'.$row->apcians_id.'/'.$row->reg_name.'/'.$row->email_id.'/'.$row->branch.'/'.$row->year.'/'.$row->qr_code); ?>" class="btn btn-info btn-lg">PAID</a>
                     </td>  
                     
                </tr>  
           <?php       
                }  
           }  
           else  
           {  
           ?>  
                <tr>  
                     <td colspan="5">No Data Found</td>  
                </tr>  
           <?php  
           }  
           ?>  
           </table> 
          
          
          
          
          
          
          
      </div> 
        
        
        
        
        
        
        
<script type="text/javascript">
    $(document).ready(function () {
 
        $('#master').on('click', function(e) {
         if($(this).is(':checked',true))  
         {
            $(".sub_chk").prop('checked', true);  
         } else {  
            $(".sub_chk").prop('checked',false);  
         }  
        });
 
        
               
                }  
            }  
        });
    });
</script>
        
        
        
    
    </form>
    
    </body>

</html>